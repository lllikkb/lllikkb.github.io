# 直播业绩统计仪表板（视频数据复盘看板）

纯前端单文件看板，所有数据与截图已内嵌，无需后端、无需其他文件夹。

## 数据概览
- 覆盖 2026-01 至 2026-11，共 164 天
- 194 张复盘截图全部内嵌（已压缩为 WebP）
- 含直播 GMV、短视频 GMV、TOP5 商品、场地、最佳/第二视频等
- index.html 约 10.6 MB，低于 GitHub 网页上传 25MB 限制

## 部署到 GitHub Pages
1. 在仓库（如 lilikkb.github.io）里删除之前上传失败的 zip
2. 把 index.html 和 .nojekyll 拖进仓库根目录上传
3. Commit changes
4. Settings -> Pages -> Source 选 Deploy from a branch，分支 main、目录 / (root)，保存
5. 等 1-2 分钟，访问 https://lilikkb.github.io/
